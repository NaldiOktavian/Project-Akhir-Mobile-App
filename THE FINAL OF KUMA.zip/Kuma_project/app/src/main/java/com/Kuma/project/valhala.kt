package com.Kuma.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.Kuma.project.R

class valhala : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_valhala)

        val btnval = findViewById<Button>(R.id.btn_valhala)
        btnval.setOnClickListener { Toast.makeText(this,
                "Added to Favorite", Toast.LENGTH_LONG).show() }
    }
}