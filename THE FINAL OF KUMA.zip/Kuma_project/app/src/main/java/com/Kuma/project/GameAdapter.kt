package com.Kuma.project

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.Kuma.project.R

class GameAdapter internal constructor(private val context: Context) :
    BaseAdapter() {
    internal var games = arrayListOf<Games>()

    override fun getCount(): Int = games.size

    override fun getItem(i: Int): Any = games[i]

    override fun getItemId(i: Int): Long = i.toLong()

    override fun getView(
        position: Int, view: View?, viewGroup:
        ViewGroup
    ): View {
        var itemView = view
        if (itemView == null) {
            itemView =
                LayoutInflater.from(context).inflate(
                    R.layout.activity_game_list, viewGroup,
                    false
                )
        }
        val viewHolder = ViewHolder(itemView as View)

        val hero = getItem(position) as Games
        viewHolder.bind(hero)
        return itemView
    }

    private inner class ViewHolder internal constructor(view: View) {
        private val title: TextView =
            view.findViewById(R.id.title)
        private val desc: TextView =
            view.findViewById(R.id.desc)
        private val img_game1: ImageView =
            view.findViewById(R.id.img_game1)

        internal fun bind(games: Games) {
            title.text = games.name
            desc.text = games.description
            img_game1.setImageResource(games.photo)
        }
    }
}