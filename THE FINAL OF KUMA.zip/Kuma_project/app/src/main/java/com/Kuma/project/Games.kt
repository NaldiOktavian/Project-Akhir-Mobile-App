package com.Kuma.project

data class Games (
    var photo: Int,
    var name: String,
    var description: String
)