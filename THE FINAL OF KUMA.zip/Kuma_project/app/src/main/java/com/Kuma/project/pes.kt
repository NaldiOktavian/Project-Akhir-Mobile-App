package com.Kuma.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.Kuma.project.R

class pes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pes)

        val btnpes = findViewById<Button>(R.id.btn_pes)
        btnpes.setOnClickListener { Toast.makeText(this,
                "Added to Favorite", Toast.LENGTH_LONG).show() }
    }
}