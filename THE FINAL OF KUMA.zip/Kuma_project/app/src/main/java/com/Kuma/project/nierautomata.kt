package com.Kuma.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.Kuma.project.R

class nierautomata : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nierautomata)

        val btnnier = findViewById<Button>(R.id.btn_nier)
        btnnier.setOnClickListener { Toast.makeText(this,
                "Added to Favorite", Toast.LENGTH_LONG).show() }
    }
}