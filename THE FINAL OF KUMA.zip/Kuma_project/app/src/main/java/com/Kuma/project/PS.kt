package com.Kuma.project

import android.content.Intent
import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import com.Kuma.project.R

class PS : AppCompatActivity() {
    private lateinit var adapter: GameAdapter
    private lateinit var dataName: Array<String>
    private lateinit var dataDescription: Array<String>
    private lateinit var dataPhoto: TypedArray
    private var games = arrayListOf<Games>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ps_games)

        val listView: ListView = findViewById(R.id.lv_list1)

        adapter = GameAdapter(this)
        listView.adapter = adapter

        prepare()
        addItem()

        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            if (position == 0){
                val moveIntent = Intent(this@PS,
                    godofwar::class.java)
                startActivity(moveIntent)
            }
            if (position == 1){
                val moveIntent = Intent(this@PS,
                    gosofshusima::class.java)
                startActivity(moveIntent)
            }
            if (position == 2){
                val moveIntent = Intent(this@PS,
                    thelasofus::class.java)
                startActivity(moveIntent)
            }
            if (position == 3){
                val moveIntent = Intent(this@PS,
                    uncharted::class.java)
                startActivity(moveIntent)
            }
            if (position == 4){
                val moveIntent = Intent(this@PS,
                    granturismo::class.java)
                startActivity(moveIntent)
            }
            if (position == 5){
                val moveIntent = Intent(this@PS,
                    spiderman::class.java)
                startActivity(moveIntent)
            }
            if (position == 6){
                val moveIntent = Intent(this@PS,
                    Bloodborne::class.java)
                startActivity(moveIntent)
            }
            if (position == 7){
                val moveIntent = Intent(this@PS,
                    crashbandikut::class.java)
                startActivity(moveIntent)
            }

        }
    }
    private fun prepare() {
        dataName = resources.getStringArray(R.array.data_name_ps)
        dataDescription = resources.getStringArray(R.array.data_description_ps)
        dataPhoto = resources.obtainTypedArray(R.array.data_photo_ps)
    }

    private fun addItem(){
        for (position in dataName.indices) {
            val hero = Games (
                dataPhoto.getResourceId(position, -1),
                dataName[position],
                dataDescription[position]
            )
            games.add(hero)
        }
        adapter.games = games
    }
}