package com.Kuma.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.Kuma.project.R

class spiderman : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spiderman)

        val btnspider = findViewById<Button>(R.id.btn_spiderman)
        btnspider.setOnClickListener { Toast.makeText(this,
                "Added to Favorite", Toast.LENGTH_LONG).show() }
    }
}