package com.Kuma.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.Kuma.project.R

class legion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_legion)

        val btnlegion = findViewById<Button>(R.id.btn_legion)
        btnlegion.setOnClickListener { Toast.makeText(this,
                "Added to Favorite", Toast.LENGTH_LONG).show() }
    }
}